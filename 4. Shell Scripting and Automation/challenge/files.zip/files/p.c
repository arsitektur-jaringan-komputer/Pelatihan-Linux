#include <stdio.h>
#include <string.h>
#include <ctype.h>

void recur(char* s, int i, int len) {
  if (i == len) return;

  if (i != 0) {
    s[i] = s[i] + (s[i - 1] - 'A') + 1;
    printf("%c\n", s[i]);
    if (s[i] > 'Z') {
      s[i] = 'A' + s[i] - 'Z' - 1;
      printf("dalam: %c\n", s[i]);
    }
  }

  recur(s, i + 1, len);
}

int main() {
  char str[105];

  scanf("%s", str);
  for (int i = 0; i < strlen(str); i++) {
    if (!isalpha(str[i])) {
      printf("INPUT SALAH!");
      return 0;
    }
    str[i] = toupper(str[i]);
  }

  recur(str, 0, strlen(str));
  printf("%s", str);

  return 0;
}