import random

max_number = 1_000_000_000_000_000_000

testcase_size = 9
for i in range(testcase_size):
  a = random.randint(0, max_number)
  b = random.randint(0, max_number)
  c = random.randint(0, max_number)

  with open(f"secret/secret_{i}.in", "w") as input_file:
    input_file.write(f"{a} {b} {c}\n")

  with open(f"secret/secret_{i}.ans", "w") as output_file:
    output_file.write(f"{a + b + c}\n")
