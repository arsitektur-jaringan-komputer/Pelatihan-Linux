#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

char arr[105];
char hasil[105];
int a = 0;
int rek(char arr[], char hasil[]) {
  if (a == strlen(arr) - 1) {
    return 0;
  }
  hasil[a + 1] = hasil[a] + hasil[a + 1] - 64;
  if (hasil[a + 1] > 90) hasil[a + 1] -= 26;
  printf("%c", hasil[a + 1]);
  a++;
  return rek(arr, hasil);
}

int main()
{
  scanf("%[^\n]s", arr);
  for (int i = 0; i < strlen(arr); i++) {
    if (isalpha(arr[i]) == 0) {
      printf("INPUT SALAH!");
      a = -1;
    }
    break;
  }
  if (a != -1) {
    for (int i = 0; i < strlen(arr); i++) {
      if (arr[i] > 96) arr[i] -= 32;
      hasil[i] = arr[i];
    }
    printf("%c", arr[0]);
    rek(arr, hasil);
  }
  return 0;
}
