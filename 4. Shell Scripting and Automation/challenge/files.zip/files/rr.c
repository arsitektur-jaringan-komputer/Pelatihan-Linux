#include <stdio.h>

int main() {
  int n;
  scanf("%d", &n);

  int i;
  float a, avg = 0;
  for (i = 0; i < n; i++) {
    scanf("%f", &a);
    avg += a;
  }

  printf("%.2f", avg / n);
}