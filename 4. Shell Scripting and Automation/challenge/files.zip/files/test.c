#include <stdio.h>
#include <string.h>

int main() {
  char str[101];

  fgets(str, sizeof(str), stdin);

  int length = strlen(str);

  for (int i = 0; i < length - 1; i += 2) {
    printf("%c", str[i]);
  }

  return 0;
}

